#ifndef ADD_H
#define ADD_H


void assignArray(int size,float *number,float *oldArray);
void printArray(int size,float sum ,float *newArray);

#endif