#include <iostream>
#include <fstream>
#include "functions.h"

int main(int argc, const char *argv[])
{

    float number = 0;
    float sum = 0;
    int arraySize = 0;
    float *numberArray = new float[arraySize]();
    float *newArray = new float[arraySize]();

    std::ifstream myReadFile;

    myReadFile.open(argv[1]);
    
    while (myReadFile >> number)
    {
        sum += number;
        assignArray(arraySize,&number, numberArray);
        arraySize++;
    }

    myReadFile.close();
    
    printArray(arraySize,sum,numberArray);
    std::cin.get();
    delete [] numberArray;
    numberArray = nullptr;
    return 0;
}
