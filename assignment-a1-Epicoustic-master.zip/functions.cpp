#include "functions.h"
#include <iostream>

void assignArray(int size,float *number, float *oldArray){
    oldArray[size] = *number;
}

void printArray(int size,float sum ,float *newArray){
    float totalAverage = sum/size;
    if(size == 0){
        std::cout << "0";
    }
    for (int i = 0;i < size;i++){
        if(newArray[i] > totalAverage){
            std::cout << newArray[i] << " ";
        }
    
    }
}
